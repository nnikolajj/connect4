Mein MinMax und Alpha Beta funktionieren

Doch ich habe nicht wirklich viel an der Performance geändert und auch sonst nicht viel zusatz gemacht.
Aber einige Kommentare habe ich geschrieben

Selbsteinschätzung : 4.5
