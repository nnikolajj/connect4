package ch.bbw.m411.connect4;

import java.util.ArrayList;
import java.util.List;

public class GoodPlayer extends Connect4ArenaMain.DefaultPlayer {

   private  int bestMove = Connect4ArenaMain.NOMOVE;
    private final int depth;
    private final int[] points = {1,2,3,4,3,2,1};
    private List<Integer> possibleMoves;

    public GoodPlayer(int depth) {
        this.depth = depth;
    }

    @Override
    int play() {
        possibleMoves = new ArrayList<>();
        //alpha beta
        getScore(myColor, depth, -10000, 10000);
        return bestMove;
    }

    //Min max Methode
    private long getScore(Connect4ArenaMain.Stone myColor, int depth) {
        possibleMoves = getPossibleMoves();

        //lost
        if (Connect4ArenaMain.isWinning(board, myColor.opponent())) {
            return -10000;
        }

        if (depth == 0) {
            return points(myColor);
        }

        //draw
        if (possibleMoves.size() == 0) {
            return points(myColor);
        }

        //setting min value
        long bestValue = Integer.MIN_VALUE;
        for (int i : possibleMoves) {
            if (board[i] == null) {
                board[i] = myColor;

                var currentValue = -getScore(myColor.opponent(), depth - 1);

                if (currentValue > bestValue) {
                    bestValue = currentValue;
                    if (depth == this.depth) {
                        bestMove = i;
                    }
                }

                //Clear Board back
                board[i] = null;
            }
        }
        return bestValue;
    }

    //Alpha Beta methode
    private int getScore(Connect4ArenaMain.Stone myColor, int depth, int alpha, int beta) {
        possibleMoves = getPossibleMoves();

        //lost
        if (Connect4ArenaMain.isWinning(board, myColor.opponent())) {
            return -10000;
        }

        //draw
        if (possibleMoves.size() == 0) {
            return points(myColor);
        }

        if (depth == 0) {
            return points(myColor);
        }

        //setting min Value
        int bestValue = Integer.MIN_VALUE;

        for (int i : possibleMoves) {

            //checking if the i field of the board is empty
            if (board[i] == null) {

                //play on the i field of the board
                board[i] = myColor;

                int currentValue = -getScore(myColor.opponent(), depth - 1, -beta, -alpha);

                if (currentValue > bestValue) {
                    bestValue = currentValue;
                    if (depth == this.depth) {
                        bestMove = i;
                    }
                }

                // update alpha value
                bestValue = Math.max(alpha, bestValue);

                //Clear Board back
                board[i] = null;

                // if alpha >= beta, cut-off
                if (bestValue >= beta) {
                    break;
                }
            }
        }
        return bestValue;
    }

   public int points(Connect4ArenaMain.Stone myColor) {
       int totalPoints = 0;

       for (int i = 0; i < board.length; i++) {
           if (board[i] == myColor) {
               totalPoints += points[i % 7];
           }
       }
       return totalPoints;
   }

    //get all now possible Moves to play
    public List<Integer> getPossibleMoves() {
        possibleMoves = new ArrayList<>();
        for (int i = 0; i < Connect4ArenaMain.WIDTH; i++) {
            for (int j = i; j < board.length; j++) {
                if (board[j] == null) {
                    possibleMoves.add(j);
                    break;
                }
            }
        }
        return possibleMoves;
    }
}